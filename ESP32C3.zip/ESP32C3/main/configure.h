/*
 * configure.h
 *
 *  Created on: May 20, 2024
 *      Author: hoanganh
 */

#ifndef MAIN_CONFIGURE_H_
#define MAIN_CONFIGURE_H_

// #define RS485
//#define RS232
// #define ANALOG
#define VOL
// #define AMP

#endif /* MAIN_CONFIGURE_H_ */
